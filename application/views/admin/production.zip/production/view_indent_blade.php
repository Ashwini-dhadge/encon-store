<?php init_header(); ?>
<link href="<?= base_url() ?>assets/css/pages/ribbon-page.css" rel="stylesheet">
<style>
    .lbl_class {
        font-weight: bold;
    }

    .lbl1_class {
        color: #fff;
    }

    .customtab li a.nav-link {
        padding: 4px 8px;
    }

    .wdth {
        width: 10%;
    }

    .wdth_a {
        width: 23%;
    }

    .select2-selection__choice {
        background-color: #48bc97 !important;
    }
</style>
<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->

        <!-- 1st  -->
        <div class="row">

            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="row">
                                    <div class="col-md-12">

                                        <!-- Nav tabs -->
                                        <ul class="nav nav-tabs customtab" role="tablist">
                                            <li class="nav-item"> <a class="nav-link active" data-toggle="tab"
                                                    href="#order" role="tab"><span class="hidden-sm-up"><i
                                                            class="ti-home"></i></span> <span
                                                        class="hidden-xs-down text-color">
                                                        <h6><b>Add Indent for Blade (Balaji)</b></h6>
                                                    </span></a> </li>

                                        </ul>

                                        <!-- Tab panes -->
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="order" role="tabpanel">
                                                <div class="" style="padding: 20px 0px 0px 0px;">
                                                    <div class="">
                                                        <div class="col-md-12" style="padding: 0px;">
                                                            <span class="text-color">
                                                                <h6><b>Indent (Balaji) Details</b></h6>
                                                            </span>
                                                        </div>
                                                        <table class="table table-bordered" style="width: 100%;">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Location
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>Encon India </span>
                                                                    </td>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Date of Indent
                                                                        </span>
                                                                    </td>

                                                                    <td class="wdth_a">

                                                                        <span><?php echo isset($indentDetails['indent_date']) ? $indentDetails['indent_date'] : ""; ?></span>

                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Dispatched Plan
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">

                                                                        <span><?php echo isset($indentDetails['dispatch_plan_date']) ? $indentDetails['dispatch_plan_date'] : ""; ?></span>
                                                                    </td>

                                                                </tr>
                                                                <tr>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Indent Number
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span><?php echo isset($indentDetails['indent_id']) ? $indentDetails['indent_id'] : ""; ?></span>
                                                                    </td>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Party Name
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>WHT</span>
                                                                    </td>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            FAN DAI(feet)
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>
                                                                            27mm
                                                                        </span>
                                                                    </td>

                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <span class="lbl_class">
                                                                            Size Of Mould
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span><?php echo isset($indentDetails['mould_size']) ? $indentDetails['mould_size'] : ""; ?></span>
                                                                    </td>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Hub Size
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>10mm</span>
                                                                    </td>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Blade Size
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span><?php echo isset($indentDetails['blade_size']) ? $indentDetails['blade_size'] : ""; ?></span>
                                                                    </td>

                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <span class="lbl_class">
                                                                            Blade Quantity
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>
                                                                            15
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Punching Number
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span><?php echo isset($indentDetails['blade_punching_no']) ? $indentDetails['blade_punching_no'] : ""; ?></span>
                                                                    </td>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            A TIP
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>
                                                                            <?php echo isset($indentDetails['a_tip']) ? $indentDetails['a_tip'] : ""; ?>
                                                                        </span>
                                                                    </td>

                                                                </tr>
                                                                <tr>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            color
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>
                                                                            <?php echo isset($indentDetails['color']) ? $indentDetails['color'] : ""; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Way
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>
                                                                            <?php echo isset($indentDetails['way']) ? $indentDetails['way'] : ""; ?></span>
                                                                    </td>

                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Set
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>44</span>
                                                                    </td>


                                                                </tr>

                                                                <tr>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Total Blade Quantity
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>
                                                                            <?php echo isset($indentDetails['blade_qty']) ? $indentDetails['blade_qty'] : ""; ?></span>


                                                                    </td>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Recived Qty
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span><?php echo isset($indentDetails['order_qty']) ? $indentDetails['order_qty'] : ""; ?></span>
                                                                    </td>

                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Blade Finishing Status
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>
                                                                            Top Coat
                                                                        </span>
                                                                    </td>


                                                                </tr>

                                                                <tr>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Ready For Dispatched
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>Yes</span>
                                                                    </td>
                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Dispatched Date
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>15/6/2024</span>
                                                                    </td>

                                                                    <td class="wdth">
                                                                        <span class="lbl_class">
                                                                            Dispatched Quantity
                                                                        </span>
                                                                    </td>
                                                                    <td class="wdth_a">
                                                                        <span>10</span>
                                                                    </td>


                                                                </tr>

                                                            </tbody>
                                                        </table>



                                                        <table class="table table-bordered color-bordered-table warning-bordered-table"
                                                            style="width: 100%; border-color:#48bc97 !important;">
                                                            <tbody>
                                                                <tr style="background-color:#48bc97 !important;">
                                                                    <td class="wdth"><span class="lbl1_class">Location</span></td>
                                                                    <td class="wdth"><span class="lbl1_class">Date</span></td>
                                                                    <td class="wdth" colspan="3"><span class="lbl1_class">Encon(India)Status</span></td>
                                                                    <td class="wdth" colspan="8"><span class="lbl1_class">Balaji Plant(Status)</span></td>
                                                                </tr>
                                                                <tr style="background-color:#48bc97 !important;">
                                                                    <td></td>
                                                                    <td></td>
                                                                    <td style="color:#fff;">Created</td>
                                                                    <td style="color:#fff;">Blade In Hand</td>
                                                                    <td style="color:#fff;">Blade Position</td>
                                                                    <td style="color:#fff;">Gap Check</td>
                                                                    <td style="color:#fff;">Prime</td>
                                                                    <td style="color:#fff;">Filler</td>
                                                                    <td style="color:#fff;">Putty</td>
                                                                    <td style="color:#fff;">TOP Coat</td>
                                                                    <td style="color:#fff;">Balancing</td>
                                                                    <td style="color:#fff;">Packing</td>
                                                                    <td style="color:#fff;">Ready For Dispatched</td>
                                                                </tr>

                                                                <?php foreach ($details as $value) { ?>
                                                                    <tr>
                                                                        <td>Encon India</td>
                                                                        <td><?php echo $value['date']; ?></td>
                                                                        <td><?php echo ($value['status_id'] == 1) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td>
                                                                        <td><?php echo ($value['status_id'] == 2) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td>
                                                                        <td><?php echo ($value['status_id'] == 3) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td>
                                                                        <td><?php echo ($value['status_id'] == 4) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td>
                                                                        <td><?php echo ($value['status_id'] == 5) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td>
                                                                        <td><?php echo ($value['status_id'] == 6) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td>
                                                                        <td><?php echo ($value['status_id'] == 7) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td>
                                                                        <td><?php echo ($value['status_id'] == 8) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td>
                                                                        <td><?php echo ($value['status_id'] == 9) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td>
                                                                        <td><?php echo ($value['status_id'] == 10) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td>
                                                                        <!-- <td><?php //echo ($value['status_id'] == 11) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td> -->
                                                                        <td><?php echo ($value['status_id'] == 12) ? '<span class="badge badge-success">' . $value['qty'] . '</span>' : ''; ?></td>

                                                                    </tr>
                                                                <?php } ?>
                                                            </tbody>
                                                        </table>

                                                    </div>


                                                </div>

                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div><br><br>
<!-- end row -->

<?php init_footer(); ?>