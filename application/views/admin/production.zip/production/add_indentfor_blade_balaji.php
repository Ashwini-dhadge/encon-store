<?php init_header(); ?>
<link href="<?= base_url() ?>assets/css/pages/stylish-tooltip.css" rel="stylesheet">
<link href="<?= base_url() ?>assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet"
    type="text/css" />
<link href="<?= base_url() ?>assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet"
    type="text/css" />
<!--alerts CSS -->
<link href="<?= base_url() ?>assets/node_modules/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
<style>
.sd {
    display: none;
}

.file-drop-zone-title {
    padding: 15px 10px !important;
}

.file-preview-image {
    width: auto !important;
    height: 40px !important;
}

.file-no-browse,
.fileinput-cancel-button {
    display: none;
}

.kv-file-content {
    display: none !important;
}

.color-table.success-table thead th {
    background-color: #48bc97 !important;
    color: #ffffff;
}
</style>
<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form class="" action="<?php echo base_url() ?>admin/production/Indent/CreateOrderforBladeb"
                            enctype="multipart/form-data" method="post" id="frm_indent" autocomplete="off">
                            <input type="hidden" name="order_for" value="<?php echo  $type ?>">
                            <div class="row">
                                <?php if ($type == "2") { ?>
                                <div class="col-md-12 mb-3">

                                    <div class="row">
                                        <div class="col-md-12">
                                            <span class="text-color">
                                                <h6><b>Add Indent for Blade Encon(India)</b></h6>
                                            </span>
                                            <hr>
                                        </div>

                                        <div class="form-group col-md-3 ">
                                            <label style="border-color:#ced4da;" class="">Location</label>
                                            <div class="input-group">
                                                <!-- <input type="text" class="form-control" id="indent_date"  name="date" value="" required> -->
                                                <select class="form-control select2 " name="location_id"
                                                    id="location_id">
                                                    <option value="1">ENCON FAN (INDIA) PRIVATE LIMITED</option>
                                                </select>
                                            </div>

                                        </div>

                                        <div class="form-group col-md-3 ">
                                            <label style="border-color:#ced4da;" class="">Indent Date</label>
                                            <div class="input-group">
                                                <input type="date" class="form-control" id="indent_date"
                                                    name="indent_date" value="" required>

                                            </div>

                                        </div>

                                        <div class="form-group col-md-3 ">
                                            <label style="border-color:#ced4da;" class="">Delivery Date</label>
                                            <div class="input-group">
                                                <input type="date" class="form-control" id="indent_date"
                                                    name="delivery_date" value="" required>

                                            </div>

                                        </div>

                                        <!-- <div class="form-group col-md-3">
                                                <label class="">Indent No</label>
                                                <input class="form-control" type="text" id="indent_no" placeholder="CT31" name="indent_no" value="" >
                                            </div>



                                            <div class="form-group col-md-3">
                                                <label class="">Party Name</label>
                                                <select class="form-control select2 client_name" onclick="this.setAttribute('value', this.value);" required name="party_id" id="compnay_id" value="">

                                                </select>
                                            </div> -->

                                        <div class="col-md-12">
                                            <h6 class="m-b-0 mt-3" style="font-weight:bold; ">Blade Details</h6>
                                            <hr>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Mould Size</label>
                                            <select class="form-control select2 mould_size"
                                                onclick="this.setAttribute('value', this.value);" required
                                                name="mould_size" id="" value="">

                                            </select>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Blade Size</label>
                                            <input class="form-control" type="text" id="indent_no" placeholder=""
                                                name="blade_size" value="">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Blade Quantity</label>
                                            <input class="form-control" type="text" id="blade_qty" placeholder=""
                                                name="blade_qty" value="">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Create Order Quantity</label>
                                            <input class="form-control" type="text" id="blade_qty" placeholder=""
                                                name="order_qty" value="">
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label class="">Core</label>
                                            <input class="form-control" type="text" id="blade_qty" placeholder=""
                                                name="core" value="">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Way</label>
                                            <input class="form-control" type="text" id="blade_qty" placeholder=""
                                                name="way" value="" required>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">A Tip</label>
                                            <select class="form-control select2 a_tip"
                                                onclick="this.setAttribute('value', this.value);" required name="a_tip"
                                                id="" value="">

                                            </select>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Punching Number</label>
                                            <input class="form-control" type="text" id="blade_qty" placeholder=""
                                                name="blade_punching_no" value="">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Remark</label>
                                            <input class="form-control" type="text" id="blade_qty" placeholder=""
                                                name="remark" value="">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Error 404</label>
                                            <select class="form-control select2 "
                                                onclick="this.setAttribute('value', this.value);" required name="error"
                                                id="" value="">
                                                <option value="1">404</option>
                                            </select>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Type</label>
                                            <select class="form-control select2 "
                                                onclick="this.setAttribute('value', this.value);" required name="type"
                                                id="compnay_id" value="">
                                                <option value="1">Polyster</option>
                                                <option value="2">Extra Rubber</option>
                                                <option value="3">Fom Core</option>
                                                <option value="4">Rubber Bag</option>
                                            </select>
                                        </div>

                                    </div>

                                    <!--   <hr> -->
                                </div>
                                <?php } else { ?>
                                <div class="col-md-12 mb-3">

                                    <div class="row">
                                        <div class="col-md-12">
                                            <span class="text-color">
                                                <h6><b>Add Indent for Blade (Balaji)</b></h6>
                                            </span>
                                            <hr>
                                        </div>

                                        <div class="form-group col-md-3 ">
                                            <label style="border-color:#ced4da;" class="">Location</label>
                                            <div class="input-group">
                                                <!-- <input type="text" class="form-control" id="indent_date"  name="date" value="" required> -->
                                                <select class="form-control select2 " name="location_id" readonly
                                                    id="location_id">
                                                    <option value="1">PLOT NO.123 ((ECTPL)), SINNAR TALUKA AUDYOGIK
                                                        VAS... </option>
                                                </select>
                                            </div>

                                        </div>

                                        <div class="form-group col-md-3 ">
                                            <label style="border-color:#ced4da;" class="">Indent Date</label>
                                            <div class="input-group">
                                                <input type="date" class="form-control" id="indent_date"
                                                    name="indent_date" readonly
                                                    value="<?php echo $blade_data['date']; ?>" required>

                                            </div>

                                        </div>

                                        <div class="form-group col-md-3 ">
                                            <label style="border-color:#ced4da;" class="">Displach Plan</label>
                                            <div class="input-group">
                                                <input type="date" class="form-control" readonly id="indent_date"
                                                    name="dispatch_date" value="<?php echo $blade_data['date']; ?>"
                                                    required>

                                            </div>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Indent No</label>

                                            <input class="form-control" type="text" id="indent_no" placeholder=""
                                                name="indent_id" value="<?php echo $blade_data['indent_no']; ?>"
                                                readonly>


                                        </div>



                                        <div class="form-group col-md-3">
                                            <label class="">Party Name</label>
                                            <select class="form-control select2 client_name" disabled
                                                onclick="this.setAttribute('value', this.value);" required
                                                name="compnay_id" id="party_id" value="">
                                                <option value="1">WHT </option>
                                            </select>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">FAN DIA(feet)</label>
                                            <input class="form-control" type="text" id="indent_no" readonly
                                                placeholder="16" name="fan_dia_feet" value="">
                                        </div>

                                        <div class="col-md-12">
                                            <h6 class="m-b-0 mt-3" style="font-weight:bold; ">Blade </h6>
                                            <hr>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Mould Size</label>
                                            <select class="form-control select2 " required name="mould_size" readonly>
                                                <option value="<?php echo $blade_data['mould_size'] ?>">
                                                    <?php echo $blade_data['mould_size'] ?> </option>
                                            </select>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Hub Size</label>
                                            <input class="form-control" type="text" id="indent_no" readonly
                                                placeholder="" name="hub_size" value="">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Blade Size</label>
                                            <input class="form-control" type="text" id="indent_no" readonly
                                                placeholder="" name="blade_size"
                                                value="<?php echo $blade_data['blade_size'] ?>">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Blade Quantity</label>
                                            <input class="form-control" type="text" id="blade_qty" readonly
                                                placeholder="4" name="blade_qty"
                                                value="<?php echo $blade_data['blade_qty'] ?>">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Punching Number</label>
                                            <input class="form-control" type="text" id="blade_qty" readonly
                                                placeholder="" name="blade_punching_no"
                                                value="<?php echo $blade_data['blade_punching_no'] ?>">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">A Tip</label>
                                            <select class="form-control select2" required name="a_tip" id="" readonly>
                                                <option value="<?php echo $blade_data['a_tip'] ?>"><?php echo $blade_data['a_tip'] ?> </option>
                                            </select>
                                        </div>



                                        <div class="form-group col-md-3">
                                            <label class="">Color</label>
                                            <input class="form-control" type="text" readonly id="blade_qty"
                                                placeholder="white" name="color"
                                                value="<?php echo $blade_data['color'] ?>">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Name Plate</label>
                                            <input class="form-control" type="text" id="blade_qty" readonly
                                                placeholder="44" name="name_plate"
                                                value="<?php echo $blade_data['name_plate'] ?>">
                                        </div>

                                        <div class="col-md-12">
                                            <h6 class="m-b-0 mt-3" style="font-weight:bold; ">Details</h6>
                                            <hr>
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label class="">Way</label>
                                            <input class="form-control" type="text" id="blade_qty" placeholder=""
                                                name="way" value="" required>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Set</label>
                                            <input class="form-control" type="text" id="blade_qty" placeholder=""
                                                name="order_set" value="" required>
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Total Blade Quantity</label>
                                            <input class="form-control" type="text" id="total_blade_qty" readonly
                                                placeholder="" name="total_blade_qty"
                                                value="<?php echo $blade_data['blade_qty'] ?>">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <label class="">Create Order Quantity</label>
                                            <input class="form-control" type="text" id="create_order_qty" placeholder=""
                                                name="order_qty" value="" required>
                                        </div>

                                        <!-- <div class="form-group col-md-3">
                                                <label class="">Blade Finishing Status</label>
                                                <select class="form-control select2 "
                                                    onclick="this.setAttribute('value', this.value);" required
                                                    name="status_finishing" id="compnay_id" value="">
                                                    <option value="1">Gap Checking</option>
                                                    <option value="2">Primer</option>
                                                    <option value="3">Filler</option>
                                                    <option value="4">Putty</option>
                                                    <option value="5">Top Coat</option>
                                                    <option value="6">Balancing</option>
                                                    <option value="7">Packing</option>
                                                </select>
                                            </div>


                                            <div class="form-group col-md-3">
                                                <label class="">Dispatched Date</label>
                                                <input class="form-control" type="date" id="" placeholder=""
                                                    name="dispatched_date">
                                            </div>

                                            <div class="form-group col-md-3">
                                                <label class="">Dispatched Quantity</label>
                                                <input class="form-control" type="text" id="" placeholder=""
                                                    name="dispatched_qty" value="">
                                            </div>


                                            <div class="form-group col-md-3 ">
                                                <fieldset>

                                                    <div class="custom-control custom-checkbox mt-4">
                                                        <input type="checkbox" name="ready_to_dispatch"
                                                            data-validation-maxchecked-maxchecked="2"
                                                            data-validation-maxchecked-message="Don't be greedy!"
                                                            class="custom-control-input" id="customCheck8" value="1">
                                                        <label class="custom-control-label" for="customCheck8">Ready For
                                                            Dispatched</label>
                                                    </div>
                                                </fieldset>

                                            </div> -->

                                    </div>

                                    <!--   <hr> -->
                                </div>
                                <?php } ?>
                                <!--  <div class="row"> -->

                                <hr>
                                <button type="submit" class="btn btn-success btn-theme float-right"
                                    style="margin-left: 94%;">Submit</button>
                        </form>



                    </div>



                </div>
            </div>
        </div>
    </div>
</div>
<!-- end row -->
<?php init_footer(); ?>

<!-- Sweet-Alert  -->
<script src="<?= base_url(); ?>assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
<script src="<?= base_url(); ?>assets/node_modules/sweetalert2/sweet-alert.init.js"></script>
<script src="<?= base_url(); ?>assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script src="<?= base_url() ?>assets/node_modules/jquery-validation/jquery.validate.js"></script>

<script src="<?= base_url(); ?>assets/js/page-js/production/indent.js"></script>
<script src="<?= base_url(); ?>assets/js/custom_common.js"></script>
<script>
// Date Picker
jQuery('.mydatepicker, #datepicker').datepicker();
jQuery('#datepicker-autoclose').datepicker({
    autoclose: true,
    todayHighlight: true
});
</script>
<script>
$(document).ready(function() {
    $('#frm_indent').validate();

    function validateQuantities() {

        var totalBladeQty = parseFloat($("#total_blade_qty").val());
        var createOrderQty = parseFloat($("#create_order_qty").val());


        if (!isNaN(totalBladeQty) && !isNaN(createOrderQty)) {
            if (totalBladeQty < createOrderQty) {

                alert(" Create Order Quantity cannot be greater than Total Blade Quantity.");
                $("#create_order_qty").val("");
                return false;
            }
        }
        return true;
    }
    $("#create_order_qty").on("change", function() {
        validateQuantities();
    });
});
</script>
<style>
.error {
    color: red;
}
</style>