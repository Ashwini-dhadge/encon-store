<?php init_header(); ?>
<link href="<?= base_url()?>assets/css/pages/stylish-tooltip.css" rel="stylesheet">
<link href="<?= base_url(); ?>/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url(); ?>/assets/node_modules/daterangepicker/daterangepicker.css" rel="stylesheet">
<link href="<?= base_url(); ?>/assets/node_modules/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">
<style>
   body {
   font-family: "Lato Regular", sans-serif;
   }
   .form-group {
   min-height: 28px;
   font-size: 14px;
   }
   .form-control {
   font-size: 0.8rem;
   }
   label{
   margin-bottom: 0.2rem;
   }
   textarea{
   height:0px !important;
   }
   /*label.error{
   display: none !important;
   }*/
   .error{
   color:red;
   }
   .sd{
   display: none;
   }
   hr {
   margin-top: 0.5rem;
   }
   .text_area{
   margin-top: -4px !important;
   line-height: 2 !important;
   }
   .margin-bottom-7{
   margin-bottom:10px !important;
   }
   .select2-container{
   margin-bottom: 7px !important;
   }
   .upper_case
   {
   text-transform: uppercase;
   }
   .select2-selection{
   height: 32px !important;
   }
</style>
<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
   <!-- ============================================================== -->
   <!-- Bread crumb and right sidebar toggle -->
   <!-- ============================================================== -->
   <div class="row">
      <div class="col-12">
         <div class="card">
            <div class="card-body">
             
               <form method="post" action="<?= base_url('admin/store/StockReport/generate_pdf');?>" id="form" enctype="multipart/form-data"class="form-horizontal">
                  <div class="row">
                     <!-- <input type="hidden" name="id" id="id" value="<?= isset($itemgroup)? $itemgroup['id'] : ''; ?>"> -->
                     <div class="col-md-12 mb-3">
                        <div class="row">
                           <div class="col-md-12">
                              <span class="text-color">
                                 <h6><b>Stock Report</b></h6>
                              </span>
                              <hr>
                           </div>
                         
                           <div class="col-md-2">
                              <label>Company</label>
                              <select class="form-control select2 did-floating-select"  id="company_id"   name="company_id" value="" >
                              </select>
                           </div>
                           <div class="col-md-2">
                              <label>Site</label>
                              <select class="form-control select2 did-floating-select"  id="site_id"   name="site_id" value="" >
                              </select>
                           </div>
                           <div class="col-md-2">
                              <label>Item Group</label>
                              <select class="form-control select2 did-floating-select select2 item_group_select2"  id="item_group_id"   name="item_group_id" value="" >
                              </select>
                           </div>
                           <div class="col-md-2">
                              <label>From Date</label>
                              <div class="input-group" style="width:100%">
                                 <input type="text" class="form-control mydatepicker" placeholder="mm/dd/yyyy" name="from_date" id="from_date" value="" required >
                                 <div class="input-group-append">
                                    <span class="input-group-text"><i class="ti-calendar"></i></span>
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-2">
                              <label>To Date</label>
                              <div class="input-group" style="width:100%">
                                 <input type="text" class="form-control mydatepicker" placeholder="mm/dd/yyyy" name="to_date" id="to_date" value="" required>
                                 <div class="input-group-append">
                                    <span class="input-group-text"><i class="ti-calendar"></i></span>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <hr>
                  </div>
                  <input type="submit" id="btnsubmit" style="margin-left: 90%;" class="btn btn-success btn-theme float-right" value="Stock Report">



<!-- <a href="<?= base_url('admin/store/StockReport/generate_pdf');?>" title="stockreport_pdf"  target="_blank" 
   class="btn btn-success btn-theme float-right" 
   data-toggle="tooltip" 
   style="font-size: 13px; background: #F0F0F0; color: gray;">
  
    Stock Report&nbsp;<i class="fas fa-print"></i>


</a> -->


           <!--      <a href="'.base_url().STOCK_PDF_PATH'" title="stockreport_pdf" target="_blank" class="btn btn-success btn-theme float-right"data-toggle="tooltip" style="font-size:13px;background:#F0F0F0;color: gray;">Stock Report&nbsp;<i class="fas fa-print" aria-hidden="true"></i></a> -->

     
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- end row -->
<?php init_footer(); ?>
<script src="<?= base_url(); ?>/assets/js/page-js/store/stock_report.js"></script>
<script src="<?= base_url(); ?>/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script src="<?= base_url(); ?>/assets/node_modules/daterangepicker/daterangepicker.js"></script>
<script>
   $(document).ready(function () {
     
      $('#frm_issue').validate();
        //   var validator = $(this[0].form).validate();
        
   });
   
   
   
</script>
<script>
   $('.daterange').daterangepicker();
   var date = new Date();
   var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
   
   $('.mydatepicker').datepicker({
    defaultDate: today,
      format: 'dd/mm/yyyy',
   });
   
   $('.myPreviousDatepicker').datepicker({
    defaultDate: today,
    minDate: null  // Set the minimum date to today, preventing selection of previous dates
   });
   
</script>