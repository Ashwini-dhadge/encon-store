<link href="<?= base_url()?>assets/css/pages/stylish-tooltip.css" rel="stylesheet">
<style>
  .select2-selection__rendered {
      margin-top: 1px;
   }
   .margin-bottom-7 {
      margin-bottom: 7px !important;
   }
   .margin-bottom-20 {
      margin-bottom: 20px !important;
   }
   label {
      margin-bottom: 0.2rem;
   }
   #mapping {
      margin-left: 20px;
   }
   form label {
      font-weight: 628;
   }
   .select2-selection--multiple{
   border: solid #ced4da 1px !important;
   }
   .datepicker{
   z-index: 1100 !important;
   }
   .error{
   color:red;
   }
</style>
<form method="post" action="<?= base_url(ADMIN . 'indent/Indent/saveIndentAllModule') ?>" id="form" enctype="multipart/form-data">

   <div class="modal-body">
      <h4>Add Hub</h4>
      <hr>
      <input type="hidden" name="master_indent_id" id="master_indent_id" value="<?= (isset($master_indent_id) ? $master_indent_id : "") ?>">
      <input type="hidden" name="indent_id" id="indentIdModal" value="<?= (isset($indent_id) ? $indent_id : "") ?>">
      <input type="hidden" name="plant_id" id="plant_id" value="<?= (isset($plant_id) ? $plant_id : "") ?>">
      <input type="hidden" id="id" name="id" value="<?= (isset($id) ? $id : "") ?>">
      <div class="row">
         <div class="form-group col-md-4 mt-1">
            <label class="">Hub Plate/Hub Size</label>
            <select class="form-control select2 did-floating-select hub_size" id="hub_size" required name="hub_size">
               <option value="">Select</option>
            
            </select>
            <label id="hub_size-error" class="error" for="hub_size"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label class="">Hub Material</label>
            <select class="form-control select2 did-floating-select material" id="material" required name="hub_material">
            </select>
            <label id="material-error" class="error" for="material"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label style="border-color:#ced4da;" class="">Bore</label>
            <input class="form-control" type="text" placeholder="" name="bore" required id="bore" value="<?= isset($bore) ? $bore : ''; ?>">
            <label id="bore-error" class="error" for="bore"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label class="">Taper Bush</label>
            <select class="form-control select2 did-floating-select" id="taper_bush" required name="taper_bush">
               <option value="">Select</option>
               <option value="tp1230">tp1230</option>
               <option value="tp4343">tp4343</option>
            </select>
            <label id="taper_bush-error" class="error" for="taper_bush"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label class="">Taper Bush Material</label>
            <select class="form-control  did-floating-select " id="material" required name="taper_bush_material">
            <option value="">Select</option>
                <option value="HG Iron Grade 415">HG Iron Grade 415</option>
               <option value="CI Grade 20">CI Grade 20</option> 
               <option value="SS304">SS304</option> 
               <option value="SS316">SS316</option> 
               <option value="SS316L">SS316L</option> 
               <option value="MS">MS</option> 
            </select>
            <label id="material-error" class="error" for="material"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label style="border-color:#ced4da;" class="">Key Way</label>
            <input class="form-control" type="text" placeholder="" name="keyway" required id="keyway" value="<?= isset($keyway) ? $keyway : ''; ?>">
            <label id="keyway-error" class="error" for="keyway"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label class="">Hub Spool</label>
            <input class="form-control" type="text" placeholder="" name="hub_spool" required id="hub_spool" value="<?= isset($hub_spool) ? $hub_spool : ''; ?>">
            <label id="hub_spool-error" class="error" for="hub_spool"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label class="">Hub Spool Material</label>
            <select class="form-control  did-floating-select " id="material" required name="hub_spool_material">

               <option value="taper">taper</option>
               <option value="gfbfvdx">gfbfvdx</option>
            </select>
            <label id="material-error" class="error" for="material"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label class="">Spacer</label>
            <input class="form-control" type="text" placeholder="" name="spacer" required id="spacer" value="<?= isset($spacer) ? $spacer : ''; ?>">
            <label id="spacer-error" class="error" for="spacer"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label style="border-color:#ced4da;" class="">Hardwares</label>
            <select class="form-control select2 did-floating-select hardwares" id="hardwares" required name="hardwares">
               <option value="">Select</option>
            
            </select>
            <label id="hardwares-error" class="error" for="hardwares"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label style="border-color:#ced4da;" class="">Qty</label>
            <input class="form-control" type="text" placeholder="" name="qty" required id="qty" value="<?= isset($qty) ? $qty : ''; ?>">
            <label id="qty-error" class="error" for="qty"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label style="border-color:#ced4da;" class="">Clamp way</label>
            <input class="form-control" type="text" placeholder="" name="clamp_way" required id="clamp_way" value="<?= isset($clamp_way) ? $clamp_way : ''; ?>">
            <label id="clamp_way-error" class="error" for="clamp_way"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label style="border-color:#ced4da;" class="">Clamp</label>
            <select class="form-control select2 did-floating-select" id="clamp" required name="clamp">
               <option value="">Select</option>
               <option value="1(mm)">1(mm)</option>
               <option value="2(mm)">2(mm)</option>
            </select>
            <label id="clamp-error" class="error" for="clamp"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label class="">Thikness</label>
            <select class="form-control select2 did-floating-select thikness" id="thikness" required name="thikness">

               <!-- <option value="1" <?= (isset($thikness) && ($thikness == 1)) ? "selected" : "" ?>>3meter</option>
               <option value="2" <?= (isset($thikness) && ($thikness == 2)) ? "selected" : "" ?>>5meter</option> -->
            </select>
            <label id="thikness-error" class="error" for="thikness"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label class="">Treatment</label>
            <select class="form-control select2 did-floating-select" id="treatment" required name="treatment">
               <option value="MSHDG">MSHDG</option>
               <option value="ZINC PLATING">ZINC PLATING</option>
            </select>
            <label id="treatment-error" class="error" for="treatment"></label>
         </div>
         <div class="form-group col-md-4 mt-1">
            <label class="">Plate OD</label>
            <select class="form-control select2 did-floating-select plate_od" id="plate_od" required name="plate_od">

               <!-- <option value="1"  <?= (isset($treatment) && ($treatment == 1)) ? "selected" : "" ?>>Treatment</option> -->
            </select>
            <label id="plate_od-error" class="error" for="plate_od"></label>
         </div>
        
      </div>
   </div>
   <div class="modal-footer">
      <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button>
      <button type="button" class="btn   waves-effect waves-light" id="submit_btn_modal" onclick="submitAllIndentMaster()" style="background-color: #48bc97;color:white;">Add</button>
   </div>
</form>
<script src="<?= base_url() ?>assets/node_modules/jquery-validation/jquery.validate.js"></script>
<script src="<?= base_url(); ?>assets/js/page-js/indent/masters/select2.js"></script>
<script>
   $(document).ready(function () {
      $('#form').validate();
   });
</script>
