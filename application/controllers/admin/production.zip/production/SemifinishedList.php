<?php

/**
 * 
 */
class SemifinishedList extends CI_Controller
{

  function __construct()
  {
    parent::__construct();
    $this->load->model(ADMIN . 'production/SemiFinishedModel');
    isLogin();
  }

  public function index()
  {
    $data['title'] = 'Received Orders';

    $this->load->view(ADMIN . 'production/semiFinishedLists/list_Semifinished', $data);
  }

  public function listSemifinshedOrder()
  {
    $data = $_POST;
    $columns = [];
    $page = $data['draw'];
    $limit = $data['length'];
    $offset = $data['start'];
    $searchVal = $data['search']['value'];
    $sortColIndex = $data['order'][0]['column'];
    $sortBy = $data['order'][0]['dir'];
    $where = array();

    

    $count = count($this->SemiFinishedModel->getSemifinishedOrderLists($searchVal, 0, 0, 0, 0, 0, $where));
    // echo $this->db->last_query();die;
    if ($count) {
      $result = $this->SemiFinishedModel->getSemifinishedOrderLists($searchVal, $sortColIndex, $sortBy, $limit, $offset, 0, $where);
      // echo"<pre>";
      // print_r($result);die;

      
      foreach ($result as $key => $value) {

        $row = [];

        $keyPlusOne = $offset + ($key + 1);
        $row[] = '<i class="fas fa-plus-circle plus-icon" data-id="' . $value['id'] . '"></i> ' . $keyPlusOne;
        $orderFor = "";
        if ($value['order_for'] == 1) {
          $orderFor = "Indent";
        } elseif ($value['order_for'] == 2) {
          $orderFor = 'Self';
        }

        // array_push($row, $orderFor);
        array_push($row, (isset($value['indent_id']) ? $value['indent_id'] : ""));
        array_push($row, (isset($value['id']) ? $value['id'] : ""));
        array_push($row, $value['indent_date']);
        array_push($row, $value['company_name']);
        // array_push($row, $value['order_for']);
        array_push($row, '<span class="label label-success">' . $value['blade_qty']  . '</span>');
        array_push($row, (isset($value['transfer_qty']) ? '<span class="label custome-received">' . $value['transfer_qty'] . '</span>' : " "));
        array_push($row, (isset($value['gap_checking_qty']) ? '<span class="label custom-label-yeal">' . $value['gap_checking_qty'] . '</span>' : " "));
        array_push($row, (isset($value['primer_qty']) ? '<span class="label label-info">' . $value['primer_qty'] . '</span>' : " "));
        array_push($row, (isset($value['filler_qty']) ? '<span class="label label-warning">' . $value['filler_qty'] . '</span>' : " "));
        array_push($row, (isset($value['putty_qty']) ? '<span class="label custom-label-teal">' . $value['putty_qty'] . '</span>' : " "));
        array_push($row, (isset($value['top_coat_qty']) ? '<span class="label label-inverse">' . $value['top_coat_qty'] . '</span>' : " "));
        array_push($row, (isset($value['balancing_qty']) ? '<span class="label custom-label-ceal">' . $value['balancing_qty'] . '</span>' : " "));
        array_push($row, (isset($value['packing_qty']) ? '<span class="label custom-label-peal">' . $value['packing_qty'] . '</span>' : " "));
        array_push($row, (isset($value['dispatch_qty']) ? '<span class="label custom-label-keal">' . $value['dispatch_qty'] . '</span>' : " "));




        $action = '<a href="' . base_url() . 'admin/production/Indent/view_indent_blade/' . $value['id'] . '" title="view" class="btn btn-primary waves-effect waves-light btn-sm editModal"data-toggle="tooltip" style="font-size:13px;background:#F0F0F0;color: gray;" ><i class="fas fa-eye" aria-hidden="true"></i></a>';

        array_push($row, $action);



        $columns[] = $row;
      }
    }
    $response = [
      'draw' => $page,
      'data' => $columns,
      'recordsTotal' => $count,
      'recordsFiltered' => $count
    ];
    echo json_encode($response);
  }


  public function indentDetails()
  {
    $data = $_POST;
   
    $details = $this->SemiFinishedModel->indentDetails($data['id']);
    // echo"<pre>";
    // print_r($details);
    // die;
    echo json_encode($details);
  }

  public function semifinishedOrder() {
    $post = $_POST; 
    
    // Prepare new order data
    $semiFinishedOrderData = [
        'gap_checking_qty' => !empty($post['gap_checking_qty']) ? $post['gap_checking_qty'] : NULL,
        'primer_qty' => !empty($post['primer_qty']) ? $post['primer_qty'] : NULL,
        'filler_qty' => !empty($post['filler_qty']) ? $post['filler_qty'] : NULL,
        'putty_qty' => !empty($post['putty_qty']) ? $post['putty_qty'] : NULL,
        'top_coat_qty' => !empty($post['top_coat_qty']) ? $post['top_coat_qty'] : NULL,
        'balancing_qty' => !empty($post['balancing_qty']) ? $post['balancing_qty'] : NULL,
        'packing_qty' => !empty($post['packing_qty']) ? $post['packing_qty'] : NULL,
    ];

    // Fetch old data
    $oldData = $this->CommonModel->getData('tbl_indent_order_status', array('order_id' => $post['order_id']), '', '', 'row_array');

    // Update the order data
    $this->CommonModel->iudAction('tbl_indent_order_status', $semiFinishedOrderData, 'update', array('order_id' => $post['order_id']));

    // Prepare status details based on changes
    $statusDetails = [];

    if ($post['gap_checking_qty'] != $oldData['gap_checking_qty']) {
        $statusDetails[] = [
            'order_id' => $post['order_id'],
            'status_id' => $post['gapCheckingStatus'],
            'qty' => $post['gap_checking_qty'],
            'remark' => $post['gap_checking_remark'],
            'created_by' => userId(),
        ];
    }

    if ($post['primer_qty'] != $oldData['primer_qty']) {
        $statusDetails[] = [
            'order_id' => $post['order_id'],
            'status_id' => $post['primerStatus'],
            'qty' => $post['primer_qty'],
            'remark' => $post['primer_remark'],
            'created_by' => userId(),
        ];
    }

    if ($post['filler_qty'] != $oldData['filler_qty']) {
        $statusDetails[] = [
            'order_id' => $post['order_id'],
            'status_id' => $post['fillerStatus'],
            'qty' => $post['filler_qty'],
            'remark' => $post['filler_remark'],
            'created_by' => userId(),
        ];
    }

    if ($post['putty_qty'] != $oldData['putty_qty']) {
        $statusDetails[] = [
            'order_id' => $post['order_id'],
            'status_id' => $post['puttyStatus'],
            'qty' => $post['putty_qty'],
            'remark' => $post['putty_remark'],
            'created_by' => userId(),
        ];
    }

    if ($post['top_coat_qty'] != $oldData['top_coat_qty']) {
        $statusDetails[] = [
            'order_id' => $post['order_id'],
            'status_id' => $post['topCoatStatus'],
            'qty' => $post['top_coat_qty'],
            'remark' => $post['top_coat_remark'],
            'created_by' => userId(),
        ];
    }

    if ($post['balancing_qty'] != $oldData['balancing_qty']) {
        $statusDetails[] = [
            'order_id' => $post['order_id'],
            'status_id' => $post['balancingStatus'],
            'qty' => $post['balancing_qty'],
            'remark' => $post['balancing_remark'],
            'created_by' => userId(),
        ];
    }

    if ($post['packing_qty'] != $oldData['packing_qty']) {
        $statusDetails[] = [
            'order_id' => $post['order_id'],
            'status_id' => $post['packingStatus'],
            'qty' => $post['packing_qty'],
            'remark' => $post['packing_remark'],
            'created_by' => userId(),
        ];
    }

    // Insert new records if any quantity has changed
    foreach ($statusDetails as $details) {
        if ($details['qty'] > 0) {
            $this->CommonModel->iudAction('tbl_indent_order_status_details', $details, 'insert');
        }
    }

    // Set success message and return response
    $this->session->set_flashdata('success', 'Order Status Updated Successfully');
    echo json_encode([
        'status' => 'success',
        'message' => 'Order Status updated successfully!'
    ]);
}


  public function dispatchOrder()
  {
    $post = $_POST;
    // echo"<pre>";
    // print_r($post);
    $olddata = $this->CommonModel->getData('tbl_indent_order_status',['order_id'=>$post['order_id']],'','','row_array');

    $updateDispatchQty = $olddata['dispatch_qty'] + $post['dispatch_qty'];

    $updatePackingQty = $post['packingQty'] - $post['dispatch_qty'];
    $data = [
      'packing_qty' =>$updatePackingQty,
      'dispatch_qty' => $updateDispatchQty,
    ];
    // print_r($data);
    // die;
    $this->CommonModel->iudAction('tbl_indent_order_status', $data, 'update', ['order_id' => $post['order_id']]);

    $statusData = [
      'order_id' => $post['order_id'],
      'status_id' => $post['status'],
      'qty' => $post['dispatch_qty'],
      'created_by' => userId(),
    ];
    $this->CommonModel->iudAction('tbl_indent_order_status_details', $statusData, 'insert');
    // print_r($statusData);
    // die;
    $this->session->set_flashdata('success', 'Order Dispatch Succesfully ');

    echo json_encode([
      'status' => 'success',
      'message' => 'Order Dispatch Succesfully'
    ]);
  }
  
}
