<?php

/**
 * 
 */
class ReceivedOrders extends CI_Controller
{

  function __construct()
  {
    parent::__construct();
    $this->load->model(ADMIN . 'production/ReceivedOrderModel');
    isLogin();
  }

  public function index()
  {
    $data['title'] = 'Received Orders';

    $this->load->view(ADMIN . 'production/receivedOrders/list_Received_order', $data);
  }

  public function listReceivedOrders()
  {
    $data = $_POST;
    $columns = [];
    $page = $data['draw'];
    $limit = $data['length'];
    $offset = $data['start'];
    $searchVal = $data['search']['value'];
    $sortColIndex = $data['order'][0]['column'];
    $sortBy = $data['order'][0]['dir'];
    $where = array();



    $count = count($this->ReceivedOrderModel->getReceivedOrders($searchVal, 0, 0, 0, 0, 0, $where));
    // echo $this->db->last_query();die;
    if ($count) {
      $result = $this->ReceivedOrderModel->getReceivedOrders($searchVal, $sortColIndex, $sortBy, $limit, $offset, 0, $where);
      // echo"<pre>";
      // print_r($result);die;

      foreach ($result as $key => $value) {

        $row = [];

        $keyPlusOne = $offset + ($key + 1);
        $row[] = '<i class="fas fa-plus-circle plus-icon" data-id="' . $value['id'] . '"></i> ' . $keyPlusOne;
        $orderFor = "";
        if ($value['order_for'] == 1) {
          $orderFor = "Indent";
        } elseif ($value['order_for'] == 2) {
          $orderFor = 'Self';
        }

        array_push($row, $orderFor);
        array_push($row, (isset($value['indent_id']) ? $value['indent_id'] : ""));
        array_push($row, $value['indent_date']);
        array_push($row, $value['company_name']);
        // array_push($row, $value['order_for']);
        array_push($row, '<span class="label label-success">' . $value['blade_qty']  . '</span>');
        array_push($row, '<span class="label custome-received">' . $value['order_qty'] . '</span>');
        array_push($row, (isset($value['created_qty']) ? '<span class="label label-primary">' . $value['created_qty'] . '</span>' : " "));
        array_push($row, (isset($value['blade_in_hand_qty']) ? '<span class="label label-primary">' . $value['blade_in_hand_qty'] . '</span>' : " "));
        array_push($row, (isset($value['blade_position_qty']) ? '<span class="label label-primary">' . $value['blade_position_qty'] . '</span>' : " "));
        array_push($row, (isset($value['transfer_qty']) ? '<span class="label label-primary">' . $value['transfer_qty'] . '</span>' : " "));




        $action = '<a href="' . base_url() . 'admin/production/Indent/view_indent_blade/' . $value['id'] . '" title="view" class="btn btn-primary waves-effect waves-light btn-sm editModal"data-toggle="tooltip" style="font-size:13px;background:#F0F0F0;color: gray;" ><i class="fas fa-eye" aria-hidden="true"></i></a>';

        array_push($row, $action);



        $columns[] = $row;
      }
    }
    $response = [
      'draw' => $page,
      'data' => $columns,
      'recordsTotal' => $count,
      'recordsFiltered' => $count
    ];
    echo json_encode($response);
  }

  public function indentDetails()
  {
    $data = $_POST;

    $details = $this->ReceivedOrderModel->indentDetails($data['id']);
    // echo"<pre>";
    // print_r($details);
    // die;
    echo json_encode($details);
  }

  public function orderCreation()
  {
    $post = $_POST;
    // echo "<pre>";
    // print_r($post); 
    // die;
    $orderData = [
      'created_qty' => !empty($post['created_qty']) ? $post['created_qty'] : null,
      'blade_in_hand_qty' => !empty($post['blade_in_hand_qty']) ? $post['blade_in_hand_qty'] : null,
      'blade_position_qty' => !empty($post['blade_position_qty']) ? $post['blade_position_qty'] : null,
  ];
  
    // print_r($orderData);
    $oldData = $this->CommonModel->getData('tbl_indent_order_status', array('order_id' => $post['order_id']), '', '', 'row_array');
    $this->CommonModel->iudAction('tbl_indent_order_status', $orderData, 'update', array('order_id' => $post['order_id']));
    // echo "<pre>";
    // print_r($oldData);
    if (
      $post['created_qty'] != $oldData['created_qty'] ||
      $post['blade_in_hand_qty'] != $oldData['blade_in_hand_qty'] ||
      
      $post['blade_position_qty'] != $oldData['blade_position_qty']
    ) {

      $statusDetails = [];

      if ($post['created_qty'] != $oldData['created_qty']) {
        $statusDetails[] = [
          'order_id' => $post['order_id'],
          'status_id' => $post['created_status'],
          'qty' => $post['created_qty'],
          'remark' => $post['createQtyRemark'],
          'created_by' => userId(),
        ];
      }

      if ($post['blade_in_hand_qty'] != $oldData['blade_in_hand_qty']) {
        $statusDetails[] = [
          'order_id' => $post['order_id'],
          'status_id' => $post['blade_in_hand_status'],
          'qty' => $post['blade_in_hand_qty'],
          'remark' => $post['bladeHandRemark'],
          'created_by' => userId(),
        ];
      }

      if ($post['blade_position_qty'] != $oldData['blade_position_qty']) {
        $statusDetails[] = [
          'order_id' => $post['order_id'],
          'status_id' => $post['blade_position_status'],
          'qty' => $post['blade_position_qty'],
          'remark' => $post['bladePositionRemark'],
          'created_by' => userId(),
        ];
      }

      // Print the details for debugging
      // print_r($statusDetails);

      foreach ($statusDetails as $details) {
        if ($details['qty'] > 0) {
          $this->CommonModel->iudAction('tbl_indent_order_status_details', $details, 'insert');
        }
      }
    }

    $this->session->set_flashdata('success', 'Order Status updated Succesfully');

    echo json_encode([
      'status' => 'success',
      'message' => 'Order Status updated successfully!'
    ]);
  }


  public function transferOrder()
  {
    $post = $_POST;
    // echo"<pre>";
    // print_r($post);
    $olddata = $this->CommonModel->getData('tbl_indent_order_status', ['order_id' => $post['order_id']], '', '', 'row_array');
    $updateTransferQty = $olddata['transfer_qty'] + $post['transfer_qty'];
    // print_r($olddata);
    // print_r($updateTransferQty);
    // die;
    // echo "<pre>";
    // print_r($post);
    // die();
    $updateBladePostionQty = $post['transfer_qty'] - $post['blade_position_qty'];
    // $updateReceivedQty = $olddata['order_qty'] - $post['transfer_qty'];
    $data = [
      // 'order_qty' => $updateReceivedQty,
      'blade_position_qty' => $updateBladePostionQty,
      'transfer_qty' =>  $updateTransferQty,
    ];
    $this->CommonModel->iudAction('tbl_indent_order_status', $data, 'update', ['order_id' => $post['order_id']]);
    // print_r($data);

    $statusData = [
      'order_id' => $post['order_id'],
      'status_id' => $post['status'],
      'qty' => $post['transfer_qty'],
      'created_by' => userId(),
    ];
    $this->CommonModel->iudAction('tbl_indent_order_status_details', $statusData, 'insert');
    // print_r($statusData);
    // die;
    $this->session->set_flashdata('success', 'Order Succesfully Transfer to next plant!');

    echo json_encode([
      'status' => 'success',
      'message' => 'Order Succesfully Transfer to next plant!!'
    ]);
  }
}
